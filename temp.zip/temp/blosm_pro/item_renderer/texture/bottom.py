

class Bottom:
    
    def __init__(self):
        pass
    
    def getNumLevelsInFace(self, levelGroup):
        return 1