from .roof_flat import RoofFlat


class RoofGeneratrix(RoofFlat):
    pass