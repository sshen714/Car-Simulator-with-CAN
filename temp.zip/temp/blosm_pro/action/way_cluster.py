

class WayCluster:
    
    def __init__(self):
        pass
    
    def do(self, way):
        # <buildingP> is a building instance created by the parser
        # not to be confused with the building instance from <building2.renderer>
        pass
    
    def cleanup(self):
        pass